import os
import streamlit as st
from groq import Groq

st.set_page_config(
    page_title="PowerSense AI",
    page_icon="⚡",
    layout="wide"
)

st.title("⚡ PowerSense AI")
st.write(
    "AI-powered electricity bill analysis, unusual consumption detection, "
    "billing insights, and energy-saving recommendations."
)

# Get API key from Streamlit Secrets or environment variable
try:
    GROQ_API_KEY = st.secrets["GROQ_API_KEY"]
except Exception:
    GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if not GROQ_API_KEY:
    st.error("GROQ_API_KEY is missing. Add it in Streamlit Cloud → Settings → Secrets.")
    st.stop()

client = Groq(api_key=GROQ_API_KEY)

st.sidebar.header("⚡ PowerSense AI")
st.sidebar.write("Electricity management assistant for Pakistan.")
st.sidebar.markdown("""
**Features**
- 📊 Bill analysis
- ⚠️ Unusual consumption alerts
- 💰 Billing issue insights
- 💡 Energy-saving recommendations
- 🤖 AI chatbot
""")

st.header("📊 Enter Electricity Bill Information")

col1, col2 = st.columns(2)

with col1:
    current_units = st.number_input(
        "Current Month Consumption (kWh)",
        min_value=0.0,
        value=350.0,
        step=1.0
    )
    previous_units = st.number_input(
        "Previous Month Consumption (kWh)",
        min_value=0.0,
        value=280.0,
        step=1.0
    )
    current_bill = st.number_input(
        "Current Bill (PKR)",
        min_value=0.0,
        value=15000.0,
        step=100.0
    )

with col2:
    previous_bill = st.number_input(
        "Previous Bill (PKR)",
        min_value=0.0,
        value=11000.0,
        step=100.0
    )
    household_size = st.number_input(
        "Household Members",
        min_value=1,
        value=5,
        step=1
    )
    appliances = st.text_area(
        "Major Appliances",
        value="AC, Refrigerator, Washing Machine, Fans, LED Lights"
    )

if previous_units > 0:
    unit_change = ((current_units - previous_units) / previous_units) * 100
else:
    unit_change = 0

if previous_bill > 0:
    bill_change = ((current_bill - previous_bill) / previous_bill) * 100
else:
    bill_change = 0

m1, m2, m3 = st.columns(3)

with m1:
    st.metric("Current Consumption", f"{current_units:.0f} kWh", f"{unit_change:+.1f}%")

with m2:
    st.metric("Current Bill", f"PKR {current_bill:,.0f}", f"{bill_change:+.1f}%")

with m3:
    if unit_change >= 30:
        status = "⚠️ High Increase"
    elif unit_change >= 10:
        status = "Moderate Increase"
    else:
        status = "Normal"
    st.metric("Consumption Status", status)

def get_ai_response(prompt, max_tokens=1200):
    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are PowerSense AI, an electricity management "
                    "assistant for consumers in Pakistan. Give practical, "
                    "easy-to-understand answers. Never claim a billing error "
                    "definitely exists without evidence. Clearly distinguish "
                    "observations from possibilities."
                )
            },
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=max_tokens
    )
    return response.choices[0].message.content

if st.button("⚡ Analyze My Electricity Bill", type="primary", use_container_width=True):
    prompt = f"""
Analyze this household electricity information:

Current consumption: {current_units} kWh
Previous consumption: {previous_units} kWh
Current bill: PKR {current_bill}
Previous bill: PKR {previous_bill}
Household size: {household_size}
Major appliances: {appliances}
Consumption change: {unit_change:.2f}%
Bill change: {bill_change:.2f}%

Give the analysis under these headings:
1. Consumption Analysis
2. Possible Reasons for Change
3. Unusual Consumption Alert
4. Possible Billing Issues
5. Energy-Saving Recommendations
6. Priority Actions

Do not invent tariff rates or other official billing information.
"""
    with st.spinner("PowerSense AI is analyzing your bill..."):
        try:
            result = get_ai_response(prompt)
            st.subheader("🤖 PowerSense AI Analysis")
            st.markdown(result)
        except Exception as e:
            st.error("AI analysis failed. Please check your API key and try again.")
            st.caption(str(e))

st.divider()
st.header("🤖 Ask PowerSense AI")

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

question = st.chat_input("Ask about your electricity bill...")

if question:
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    context = f"""
Current consumption: {current_units} kWh
Previous consumption: {previous_units} kWh
Current bill: PKR {current_bill}
Previous bill: PKR {previous_bill}
Household size: {household_size}
Major appliances: {appliances}

Question: {question}
"""
    with st.chat_message("assistant"):
        with st.spinner("PowerSense AI is thinking..."):
            try:
                answer = get_ai_response(context, max_tokens=800)
                st.markdown(answer)
                st.session_state.messages.append(
                    {"role": "assistant", "content": answer}
                )
            except Exception as e:
                st.error("Unable to answer. Please check your API configuration.")
                st.caption(str(e))

st.divider()
st.caption("⚡ PowerSense AI | AI Transformation & Innovation Challenge Prototype")
